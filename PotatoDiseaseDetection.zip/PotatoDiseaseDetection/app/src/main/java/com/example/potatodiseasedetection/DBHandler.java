package com.example.potatodiseasedetection;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DBHandler extends SQLiteOpenHelper {
    private static final String db_name = "User";
    private static final int DB_no = 1;
    DBHandler(Context context)
    {
        super(context,db_name,null,DB_no);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String query  = "create table user_info (name TEXT,email TEXT PRIMARY KEY,password TEXT);";
        System.out.println("Hey");
        sqLiteDatabase.execSQL(query);
    }
    public boolean addNewUser(String email, String user_name, String password)
    {

        SQLiteDatabase db = this.getWritableDatabase();
        SQLiteDatabase db1 = this.getReadableDatabase();
        Cursor cursor = db1.rawQuery("SELECT *FROM user_info",null);
        boolean flag = true;
        String[] names =cursor.getColumnNames();
        for(int i =0;i<names.length;i++)
        {
            System.out.println(names[i]);
        }
        while(cursor.moveToNext())
        {
            String temp = cursor.getString(1);
            System.out.println(temp+" "+email);
            if(temp.equals(email))
            {
                System.out.println("HEy Hello");
                return  false;
            }
        }
        ContentValues values = new ContentValues();
        values.put("email",email);
        values.put("name",user_name);
        values.put("password",password);
        db.insert("user_info",null,values);
        System.out.println(cursor.getCount());
        db.close();
        return true;
    }
    public boolean check_user(String email,String password)
    {
        SQLiteDatabase db1 = this.getReadableDatabase();

        Cursor cursor = db1.rawQuery("SELECT *FROM user_info",null);
        while(cursor.moveToNext())
        {
            String temp = cursor.getString(1);

            System.out.println(temp);

            if(temp.equals(email))
            {
                System.out.println("Hey");
                if(password.equals(cursor.getString(2)))
                {
                    System.out.println(password);
                    return true;
                }
                else return false;
            }
        }
        return false;
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS user_info");
        onCreate(db);
    }
}

