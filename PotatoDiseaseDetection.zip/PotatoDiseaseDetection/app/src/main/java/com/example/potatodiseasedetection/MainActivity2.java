package com.example.potatodiseasedetection;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import  android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    DBHandler database;
    Button sign_up;
    EditText email,password,user_name,confirm_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = new DBHandler(this);
        sign_up = (Button) findViewById(R.id.sign_up);
        user_name = (EditText) findViewById(R.id.user_name);
        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);
        confirm_password = (EditText) findViewById(R.id.confirm_password);

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Email = email.getText().toString();
                String User_name = user_name.getText().toString();
                String pass = password.getText().toString();
                String pass2 = confirm_password.getText().toString();
                if(!(pass.equals(pass2))||pass.isEmpty())
                {
                    Toast.makeText(MainActivity2.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (database.addNewUser(Email,User_name,pass))
                {
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "The email has been taken", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}