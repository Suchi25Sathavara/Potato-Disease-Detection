package com.example.potatodiseasedetection;


import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity3 extends Activity {
    private static final int CAMERA_REQUEST = 1899;
    private ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Button camera = (Button) findViewById(R.id.camera);
        Button upload = (Button) findViewById(R.id.upload);
        imageView = (ImageView) findViewById(R.id.imageView);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAMERA_REQUEST);
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 1);
            }
        });


    }
    @Override
    protected  void onActivityResult(int req,int res,Intent data)
    {
        if(res == RESULT_OK && req == 1)
        {
            try {
                Uri image_path = data.getData();
                System.out.println(image_path);
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), image_path);
                imageView.setImageURI(image_path);
                imageView.setImageBitmap(bitmap);
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
        }
        else if(req == CAMERA_REQUEST)
        {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imageView.setImageBitmap(bitmap);
        }
    }
}